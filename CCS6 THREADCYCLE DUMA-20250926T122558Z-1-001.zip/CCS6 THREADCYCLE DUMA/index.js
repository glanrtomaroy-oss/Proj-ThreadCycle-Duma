export { default as HomePage } from "./HomePage";
export { default as ScrapEstimatorPage } from "./ScrapEstimatorPage";
export { default as TutorialsPage } from "./TutorialsPage";
export { default as ThriftMapPage } from "./ThriftMapPage";
export { default as AboutPage } from "./AboutPage";
export {default as LoginPage} from "./LoginPage";
export { default as AdminPage } from './AdminPage';